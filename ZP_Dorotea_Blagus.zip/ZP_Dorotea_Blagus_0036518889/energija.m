function [] = energija(S,t,w,KQ,s)
% v = s / t ->> t = s / v
% E = P * t
v = 0.5144*[4.5 5 5.5 6 6.6 7 7.5 8 8.5 9]; %iz cv u m/s
L = 5.9;
g = 9.81;
viskoznost = 1.1907e-6;
ro = 1025.9;
CVP = 0.00045;
n = 900/60;
D = 0.28;
eta_S = 0.96;
eta_H = (1-t)/(1-w);
Rn = zeros(10,1);
CF = zeros(10,1);
Fn = zeros(10,1);
CW = zeros(10,1);
CT = zeros(10,1);
RT = zeros(10,1);
T = zeros(10,1);
va = zeros(10,1);
J = zeros(10,1);
KT = zeros(10,1);
PE = zeros(10,1);
PD = zeros(10,1);
eta_0 = zeros(10,1);
eta_R = zeros(10,1);
eta_T = zeros(10,1);
E = zeros(10,1);
for i = 1:10
    Rn(i) = (v(i)*L)/viskoznost;
    CF(i) = 0.075/((log10(Rn(i))-2)^2);
    Fn(i) = v(i)/sqrt(g*L);
    CW(i) = 3561.3*Fn(i)^6-8812.6*Fn(i)^5+8148.4*Fn(i)^4-3454.3*Fn(i)^3+654.09*Fn(i)^2-40.235*Fn(i);
    CT(i) = CF(i) + CW(i)/10^3 + CVP;
    RT(i) = (CT(i)*ro*S*(v(i)^2))/2;
    T(i) = RT(i)/(1-t);
    va(i) = v(i)*(1-w);
    J(i) = va(i)/(n*D);
    KT(i) = T(i)/(ro*n^2*D^4);
    PE(i) = RT(i) * v(i);
    PD(i) = 2.2*PE(i);
    eta_0(i) = (KT(i)/KQ)*(J(i)/(2*pi));
    eta_R(i) = PE(i)/(eta_0(i)*eta_H*PD(i));
    eta_T(i) = eta_H*eta_0(i)*eta_R(i)*eta_S;
    E(i) = eta_T(i) * PE(i) * (s/(v(i)*3.6)); % iz m/s u km/h
end
plot(s./v,E);
xlabel('t, {\it h}');
ylabel('E, {\it Wh}');
hold on
grid on
end

