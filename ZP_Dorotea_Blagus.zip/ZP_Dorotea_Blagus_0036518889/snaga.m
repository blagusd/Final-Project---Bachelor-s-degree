function [] = snaga(S,eta_S)
L = 5.9;
g = 9.81;
viskoznost = 1.1907e-6;
ro = 1025.9;
CVP = 0.00045;
w = 0.1712;
t = 0.3403;
v = 0.5144*[4.5 5 5.5 6 6.6 7 7.5 8 8.5 9];
Rn = zeros(10,1);
CF = zeros(10,1);
Fn = zeros(10,1);
CW = zeros(10,1);
CT = zeros(10,1);
RT = zeros(10,1);
PE = zeros(10,1);
T = zeros(10,1);
va = zeros(10,1);
PT = zeros(10,1);
PD = zeros(10,1);
PB = zeros(10,1);
n = 100*[7 8 9 10 11 12]/60;
Q = zeros(6,1);
for i = 1:10
    Rn(i) = (v(i)*L)/viskoznost;
    CF(i) = 0.075/((log10(Rn(i))-2)^2);
    Fn(i) = v(i)/sqrt(g*L);
    CW(i) = 3561.3*Fn(i)^6-8812.6*Fn(i)^5+8148.4*Fn(i)^4-3454.3*Fn(i)^3+654.09*Fn(i)^2-40.235*Fn(i);
    CT(i) = CF(i) + CW(i)/10^3 + CVP;
    RT(i) = (CT(i)*ro*S*(v(i)^2))/2;
    PE(i) = RT(i) * v(i);
    T(i) = RT(i)/(1-t);
    va(i) = v(i)*(1-w);
    PT(i) = T(i)*va(i);
    PD(i) = 10.6*PE(i); %uzeti cemo nesto vise od 2xPE
    PB(i) = PD(i)/eta_S;
end
for i = 5:10
    Q(i-4) = PD(i)/(2*pi*n(i-4));
end
plot(v/0.5144,PE);
hold on
grid on
plot(v/0.5144,PT);
plot(v/0.5144,PD);
plot(v/0.5144,PB);
xlabel('v, {\it cv}');
ylabel('P, {\it W}');
title('Ovisnost snage o promjeni brzine');
figure;
plot(n*60, Q);
grid on
xlabel('n, {\it o/min}');
ylabel('Q, {\it Nm}');
title('Momentna karakteristika');
end

