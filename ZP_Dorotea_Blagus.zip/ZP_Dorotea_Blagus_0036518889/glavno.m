%% Podaci o camcu
L = 5.9; %duljina [m]
h = 2; %unutarnja visina [m]
H = 2.5; %visina [m]
B = 2.1; %širina [m]
r = 10.5; %najmanji polumjer okretanja
v = 7.55; %najveća brzina [NM/h = cvor]
% 1 Nautical miles per hour [nm/h] = 0.5144 meters per second [m/s]
v = 7.55*0.5144; %[m/s]
N = 6; %broj putnika
T = 0.4; %gaz [m]
g = 9.81;
viskoznost = 1.1907e-6; %[m2/s]
ro = 1025.9; %[kg/m3]

%%
trenje(L, viskoznost); %promjena koef. trenja u odnosu na brzinu
%koeficijent za nasu zadanu brzinu:
Rn = (v*L)/viskoznost; %Raynoldsov broj
CF = 0.075/((log10(Rn)-2)^2); %frictional resistance

%CB = 1.08 - 0.5363*v/sqrt(L); %faktor istisnine
CB = 0.5; %otprilike
V = CB*L*B*T; %istisnina [m3]
S = 1.025*L*(CB*B+1.7*T); %oplakana površina [m2]

Fn = v/sqrt(g*L); %Froudov broj
CW = 3561.3*Fn^6-8812.6*Fn^5+8148.4*Fn^4-3454.3*Fn^3+654.09*Fn^2-40.235*Fn;

CVP = 0.00045;

CT = CF + CW/10^3 + CVP;
RT = (CT*ro*S*(v^2))/2; %total resistance

PE = RT * v;

%% propeler
D = 0.28;
Fa = -2;

a = (0.1*B)/L + 0.149;
b = (0.05*B)/L + 0.449;
c = 585 - (5027*B)/L + 11700*(B/L)^2;
w1 = a + b/(c*(0.98-CB)^3+1);
w2 = (0.0025*Fa)/(100*(CB-0.7)^2+1);
w3 = -0.18 + 0.00756/((D/L)+0.002);
w = w1+w2+w3;

d = (0.625*B)/L+0.08;
e = 0.165-(0.25*B)/L;
f = 525-(8060*B)/L+20300*(B/L)^2;
t1 = d + e/(f*(0.98-CB)^3+1);
t2 = -0.01*Fa;
t3 = 2*((D/L)-0.04);
t = t1 + t2 + t3;

T = RT/(1-t);
va = v*(1-w);
PT = T*va;

n = 900/60;
J = va/(n*D)
PD = 3000;
Q = PD / (2*pi*n);

KT = T/(ro*n^2*D^4);
KQ = Q/(ro*D^5*n^2);

%% korisnosti
eta_H = (1-t)/(1-w);
eta_0 = (KT/KQ)*(J/(2*pi));
eta_R = PE/(eta_0*eta_H*PD);
eta_S = 0.96;
eta_T = eta_H*eta_0*eta_R*eta_S;

PB = PD/eta_S;

%% energija
s1 = 2*16.4; % Split - Supetar
s2 = 2*5.5; % Zadar - Ugljan
s3 = 2*14; % Dubrovnik - Lopud
s4 = 2*7.2; % Šibenik - Zlarin
s5 = 2*16.5; % Split - Šolta

subplot(3,2,1)
energija(S,t,w,KQ,s1)
title('I. Split - Supetar');
subplot(3,2,2)
energija(S,t,w,KQ,s2)
title('II. Zadar - Ugljan');
subplot(3,2,3)
energija(S,t,w,KQ,s3)
title('III. Dubrovnik - Lopud');
subplot(3,2,4)
energija(S,t,w,KQ,s4)
title('IV. Šibenik - Zlarin');
subplot(3,2,5)
energija(S,t,w,KQ,s5)
title('V. Split - Šolta');

subplot(1,2,1)
energija(S,t,w,KQ,s1)
energija(S,t,w,KQ,s3)
title('Usporedba I i III');
subplot(1,2,2)
energija(S,t,w,KQ,s2)
energija(S,t,w,KQ,s4)
title('Usporedba II i IV');

E1 = eta_T*PE*(s1/(v*3.6));
E2 = eta_T*PE*(s2/(v*3.6));
E3 = eta_T*PE*(s3/(v*3.6));
E4 = eta_T*PE*(s4/(v*3.6));
E5 = eta_T*PE*(s5/(v*3.6));