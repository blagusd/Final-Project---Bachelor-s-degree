function [] = Wave_resistance_coeff()
Fn = zeros(12,1);
Cw = zeros(12,1);
Fn(1) = 0.1;
for i = 2:16
    Fn(i) = Fn(i-1) + 0.05;
    Cw(i) = 3561.3*Fn(i)^6-8812.6*Fn(i)^5+8148.4*Fn(i)^4-3454.3*
    Fn(i)^3+654.09*Fn(i)^2-40.235*Fn(i);
end
plot(Fn,Cw);
grid on
xlabel('Fn');
ylabel('1000*CW');
title('Koeficijent otpora valova u ovisnosti o Froude-ovom broju');
end

