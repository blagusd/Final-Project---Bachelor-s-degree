function [Rn,Cf] = trenje(L, viskoznost)
v = 0.5144*[4.5 5 5.5 6 6.6 7 7.5 8 8.5 9];
Rn = zeros(10, 1);
Cf = zeros(10, 1);
for i = 1:10
    Rn(i) = v(i)*L/viskoznost;
    Cf(i) = 0.075/((log10(Rn(i))-2)^2);
end
interp1q(Rn,Cf,Rn);
plot(Rn,Cf);
grid on
xlabel('Rn');
ylabel('CF');
title('Krivulja otpora trenja');
end


